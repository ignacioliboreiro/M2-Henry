
var a = require('./week.js');

console.log(a.name(0));
console.log(a.number("Lunes"));