let script = document.querySelector("#script")

let newElement = document.createElement("div")

let newElement2 = document.createElement("p")


newElement2.innerHTML = "holaaaaaaaaaaaaa"


newElement.appendChild(newElement2)
script.appendChild(newElement)