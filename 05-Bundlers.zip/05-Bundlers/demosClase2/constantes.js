// const name = "nacho"

// const a = 2
// const b = 3

//esta forma es muy usada en el back 
// module.exports = {
//     name,
//     a,
//     b
// }


//asi se usa en el front 
export const name = "nacho"

export const a = 2
export const b = 3