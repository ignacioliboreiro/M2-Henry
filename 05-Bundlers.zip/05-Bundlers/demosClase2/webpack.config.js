module.exports={
    entry:"",
    output:{
        path: __dirname + "/browser",// esto es para que le digamos donde queremos que lo guarde en este caso lo guardamos aca
        filename :"bundle.js" // asi es como se va a llamar el 
    }
}