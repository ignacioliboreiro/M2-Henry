var modulo = require('./modulo1.js');

console.log(modulo.henry);
console.log(modulo.bundeler);

console.log('Entry Point');


